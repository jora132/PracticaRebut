package com.example.myapplication;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Ticket_bay extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ticket_bay);
        int iduser = 0;
        try {
            SQLiteDatabase db = getBaseContext().openOrCreateDatabase("users.db", MODE_PRIVATE, null);
            Cursor query = db.rawQuery("SELECT id FROM (SELECT * FROM users ORDER BY id DESC LIMIT 1) t ORDER BY id;", null);
            while(query.moveToNext()) {
                iduser = Integer.parseInt(query.getString(0));

            }
            if (iduser>= 0)
            {
                TextView TV1 = (TextView) findViewById(R.id.TV1);
                TV1.setVisibility(View.VISIBLE);
                View V1 = (View) findViewById(R.id.V1);
                V1.setVisibility(View.VISIBLE);

            }
            else
            {
                Toast.makeText(getApplicationContext(), "Войдите в систему!", Toast.LENGTH_SHORT).show();
            }
        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(), "Войдите в систему!", Toast.LENGTH_SHORT).show();
        }

        OkHttpClient client = new OkHttpClient();
        String url = "https://smtpservers.ru/projects/Kochnev/ticketBuy?Id=" +id;
        Request request = new Request.Builder()
                .url(url)
                .build();
        Call call = client.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String json = response.body().string();
                if (json.equals("500")) {
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Объявления отсутствуют!", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Gson gson = new Gson();
                    ticketBuy[] adv = gson.fromJson(json, ticketBuy[].class);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ImageView imageView = findViewById(R.id.imageView);
                            String imageUrl = "https://smtpservers.ru/projects/Kochnev/uploads/"+adv[0].Picture;
                            Picasso.get()
                                    .load(imageUrl)
                                    .into(imageView);

                            TextView textView1 = findViewById(R.id.textView2);
                            textView1.setText(adv[0].Text);

                            ImageView imageView2 = findViewById(R.id.imageView1);
                            String imageUrl2 = "https://smtpservers.ru/projects/Kochnev/uploads/"+adv[0].Picture2;
                            Picasso.get()
                                    .load(imageUrl2)
                                    .into(imageView2);
                        }
                    });

                }
            }


            @Override
            public void onFailure(Call call, IOException e) {
                String error = e.toString();
            }
        });


    }
    public void bayticket(View viev)
    {
        Toast.makeText(getApplicationContext(), "Вы купили билет!", Toast.LENGTH_SHORT).show();
    }
    public static int id;
    public class ticketBuy
    {
        private int Id;
        private String Text;
        private String Picture;
        private String Picture2;
    }

}

