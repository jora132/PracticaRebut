package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import com.google.gson.Gson;

import java.io.IOException;
import java.lang.ref.Reference;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class RebutPassword extends AppCompatActivity {
public Boolean sendmessage = false;
    int finalRandomNumber;
    public String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rebut_password);
    }
    public void GoMainRebut(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void GoSecondReb(View v){
        if (sendmessage)
        {
            EditText rwqr = (EditText)findViewById(R.id.editTextTextPersonName);
            int code = Integer.parseInt(rwqr.getText().toString());
            if (code==finalRandomNumber)
            {
                RebutPassword2.email = email;
                startActivity(new Intent(this, RebutPassword2.class));
            }
        }
        else
        {
            EditText fqfwq = (EditText)findViewById(R.id.editTextTextPersonName6);
            email = fqfwq.getText().toString();
            OkHttpClient client = new OkHttpClient();
            Random random = new Random();
            int randomNumber = random.nextInt(8999) + 1000;
            finalRandomNumber = randomNumber;
            String url = "https://smtpservers.ru/projects/Kochnev/sendMessage?to=" + email + "&code=" + randomNumber + "&app=Practica&helpemail=help@smtpservers.ru";
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String responseBody = response.body().string();
                    Handler handler = new Handler(Looper.getMainLooper());
                    if (responseBody.equals("500")) {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "Аккаунт с таким email не зарегистрирован!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "Код отправлен!", Toast.LENGTH_SHORT).show();
                                sendmessage = true;

                            }
                        });

                    }
                }

                @Override
                public void onFailure(Call call, IOException e) {
                    String error = e.toString();
                }

            });
        }

    }
    public void EmailCode(View view)
    {


    }
}