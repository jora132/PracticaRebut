package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class News extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.menu_News);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        refreshGridView();

        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        GridView gridView = findViewById(R.id.gridView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId()) {
                    case R.id.menu_Matches:

                        toMatches();
                        return true;

                    case R.id.menu_News:

                        return true;
                }
                return false;
            }
        });
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run()
                    {

                    }
                });
            }


        });
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                refreshGridView();
            }
        });
    }
    public void toMatches(){
        startActivity(new Intent(this, MainPage.class));
        overridePendingTransition(0,0);
    }

    private BottomNavigationView bottomNavigationView;
    private GridView mGridView;
    private CustomGridAdapter2 mAdapter;
    private Boolean Upload = false;

    private SwipeRefreshLayout swipeRefreshLayout;
    ArrayList<String> idList = new ArrayList<>();
    public class Newss
    {
        private int Id;
        private String Text;
        private String Picture;

    }
    public void refreshGridView(){
        GridView gridView = findViewById(R.id.gridView);
        gridView.setAdapter(null);
        idList.clear();
        OkHttpClient client = new OkHttpClient();
        String url = "https://smtpservers.ru/projects/Kochnev/selectNews";
        Request request = new Request.Builder()
                .url(url)
                .build();
        Call call = client.newCall(request);

        mGridView = findViewById(R.id.gridView);

        Context context = this;
        call.enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String json = response.body().string();
                if (json.equals("500")) {
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Новости отсутствуют!", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Gson gson = new Gson();
                   Newss[] adv = gson.fromJson(json, Newss[].class);
                    String[][] array = new String[adv.length][2];
                    for(int i = 0; i < adv.length; i++){
                        idList.add(String.valueOf(adv[i].Id));
                        array[i][0] = adv[i].Text;
                        array[i][1] = adv[i].Picture;

                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mAdapter = new CustomGridAdapter2(context, array);
                            mGridView.setAdapter(mAdapter);
                        }
                    });

                }
            }

            @Override
            public void onFailure(Call call, IOException e)
            {
                String error = e.toString();
            }
        });
        if(Upload) {
            swipeRefreshLayout.setRefreshing(false);
        }else{
            Upload = true;
        }
    }
}
