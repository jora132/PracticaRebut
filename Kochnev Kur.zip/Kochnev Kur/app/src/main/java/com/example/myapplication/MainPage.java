package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;



import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import com.google.gson.Gson;

import java.io.IOException;
import java.lang.ref.Reference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Call;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import com.google.gson.Gson;

import java.io.IOException;
import java.lang.ref.Reference;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class MainPage extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;
    private GridView mGridView;
    private CustomGridAdapter mAdapter;
    private Boolean Upload = false;

    private SwipeRefreshLayout swipeRefreshLayout;
    ArrayList<String> idList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        refreshGridView();
        bottomNavigationView.setSelectedItemId(R.id.menu_Matches);
        bottomNavigationView = findViewById(R.id.bottom_navigation);

        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        GridView gridView = findViewById(R.id.gridView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId()) {
                    case R.id.menu_Matches:
                        //toHomePage();
                        return true;

                    case R.id.menu_News:

                        return true;

                }
                return false;
            }
        });
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Ticket_bay.id = Integer.parseInt(idList.get(position));
                        Toticket_bay();

                    }
                });
            }


        });
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                refreshGridView();
            }
        });
    }
    public void menu(View view )
    {

    }
    public void refreshGridView(){
        GridView gridView = findViewById(R.id.gridView);
        gridView.setAdapter(null);
        idList.clear();
        OkHttpClient client = new OkHttpClient();
        String url = "https://smtpservers.ru/projects/Kochnev/selectMatch";
        Request request = new Request.Builder()
                .url(url)
                .build();
        Call call = client.newCall(request);

        mGridView = findViewById(R.id.gridView);

        Context context = this;
        call.enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String json = response.body().string();
                if (json.equals("500")) {
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Матчи отсутствуют!", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Gson gson = new Gson();
                    Match[] adv = gson.fromJson(json, Match[].class);
                    String[][] array = new String[adv.length][3];
                    for(int i = 0; i < adv.length; i++){
                        idList.add(String.valueOf(adv[i].Id));
                        array[i][0] = adv[i].Text;
                        array[i][1] = adv[i].Picture;
                        array[i][2] = adv[i].Picture2;

                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mAdapter = new CustomGridAdapter(context, array);
                            mGridView.setAdapter(mAdapter);
                        }
                    });

                }
            }

            @Override
            public void onFailure(Call call, IOException e) {
                String error = e.toString();
            }
        });
        if(Upload) {
            swipeRefreshLayout.setRefreshing(false);
        }else{
            Upload = true;
        }
    }
    public class Match
    {
        private int Id;
        private String Text;
        private String Picture;
        private String Picture2;
    }
    public void Toticket_bay()
    {
      startActivity(new Intent(this, Ticket_bay.class));
    }
}